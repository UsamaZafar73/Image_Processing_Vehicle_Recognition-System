
function  x = pakcheck (Seethrough10)
%imshow(Seethrough10);
x=0;
seethrough = numel(Seethrough10);
%disp('part got');
%disp(seethrough);
if seethrough==0
    x=0;
    return
end
%disp('SEE THROUGH');
%disp(seethrough);
txt = ocr(Seethrough10,'Language','D:\MAYINSTALL\bin\front\myLang\tessdata\myLang.traineddata');
g=length(txt.Text);
%disp(g);
if g>7
for m = 1:7
    if (txt.Text(m) == 0||1||2||3||4||5||6||7||8||9)
        x=x+1;
       % disp(txt.Text(m));
    end
end
else 
    x=1;
end
%disp(txt.Words);
%disp(x);
return 
end 