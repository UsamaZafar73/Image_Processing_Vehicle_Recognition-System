function varargout = version2(varargin)
% VERSION2 MATLAB code for version2.fig
%      VERSION2, by itself, creates a new VERSION2 or raises the existing
%      singleton*.
%
%      H = VERSION2 returns the handle to a new VERSION2 or the handle to
%      the existing singleton*.
%
%      VERSION2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VERSION2.M with the given input arguments.
%
%      VERSION2('Property','Value',...) creates a new VERSION2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before version2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to version2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help version2

% Last Modified by GUIDE v2.5 25-May-2018 14:50:52

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @version2_OpeningFcn, ...
                   'gui_OutputFcn',  @version2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before version2 is made visible.
function version2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to version2 (see VARARGIN)

% Choose default command line output for version2
handles.output = hObject;
%{

hEdit = uicontrol('Style','Edit'); 
jEdit = findobj(hEdit);
jEdit.Border ;
jEdit.Border.get;
lineColor = java.awt.Color(1,0,0);  % =red
thickness = 3;  % pixels
roundedCorners = true;
newBorder = javax.swing.border.LineBorder(lineColor,thickness,roundedCorners);
jEdit.Border = newBorder;
jEdit.repaint;  % redraw the modified control
%}


% create an axes that spans the whole gui
ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('bgfinal.jpg'); imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes version2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = version2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in Browse.
function Browse_Callback(hObject, eventdata, handles)
% hObject    handle to Browse (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,FilePath ]= uigetfile({'*.jpg';'*.bmp';'*.png' },'File Selector');

ExPath = fullfile(FilePath, FileName);
 if isequal(FileName,0) || isequal(FilePath,0)
 h=msgbox('You Pressed Cancel','message');
  return
 end


set(handles.path,'string',ExPath);
img1=imread([FilePath,FileName]);
h=imshow(img1, 'Parent', handles.axes1);
 
im = imagemodel(h);
attrs = imattributes(im);
width=attrs(1,2);
%disp (width);
height=attrs(2,2);

[rows columns numberOfColorChannels] = size(img1);
area= rows*columns;
aspectRatio=rows/columns;
c=im2bw(img1);
%figure
%imshow(c),title('IM2BW WHOLE DIRECT');
euler=bweuler(c);
%disp ('teee');
i=rgb2gray(img1);
%figure
%imshow(i),title('WHOLE IMAGE GRAY');
J = imnoise(i,'gaussian',0,0.005);
K = wiener2(J,[5 5]);
level = graythresh(K);
BW = im2bw(K,level);
%imshow(BW),title('WHOLE IMAGE BINARY AFTER PROCESSING');
X=area;
if (450000<X) && (X<490000)  
    Seethrough10=imcrop(img1,[700, 12, 300, 80]);
x = pakcheck (Seethrough10);
Seethrough10=imcrop(img1,[470, 40, 190, 50]);
    y= paktb(Seethrough10);
if x==7 || y==1
identifier=0;
%disp('identifier');
Seethrough10=imcrop(BW,[22, 28, 128, 280-155]);
seethrough = numel(Seethrough10);
%disp('SEE THROUGH');
%disp(seethrough);
front=imcrop(BW,[800, 107, 75, 250-173]);
front = numel(front);
%disp('FRONT');
%disp(front);
else 
        h=msgbox('Not Recognized','message');
        return  
end     
elseif (500000<X) && (X<520000)
     Seethrough10=imcrop(img1,[740, 12, 180, 70]);
x = pakcheck (Seethrough10);
Seethrough10=imcrop(img1,[530, 40, 190, 40]);
    y= paktb(Seethrough10);
if x==7 || y==1
 Identifier20=imcrop(BW,[179, 390 ,85, 50]);
identifier = numel(Identifier20);
%disp('identifier');
%disp(identifier);

Seethrough20=imcrop(BW,[28, 16, 145, 295-155]);
seethrough = numel(Seethrough20);
%disp('SEE THROUGH');
%disp(seethrough);
Front20=imcrop(BW,[861, 100, 80, 280-188]);
front = numel(Front20);
%disp('FRONT');
%disp(front);
else 
        h=msgbox('Not Recognized','message');
        return  
end   

elseif (530000<X) && (X<560000)
    Seethrough10=imcrop(img1,[780, 12, 180, 70]);
x = pakcheck (Seethrough10);
Seethrough10=imcrop(img1,[615, 440, 190, 910]);
    y= pakbrs(Seethrough10);
if x==7 || y==1 
    
    Identifier50=imcrop(BW,[179, 360 ,85, 80]);
    identifier = numel(Identifier50);
%disp('identifier');
%disp(identifier);

Seethrough50=imcrop(BW,[28, 38 , 180, 290-160]);
seethrough = numel(Seethrough50);
%disp('SEE THROUGH');
%disp(seethrough);
Front50=imcrop(BW,[880, 88, 110, 295-189]);
front = numel(Front50);
%disp('FRONT');
%disp(front);
else 
        h=msgbox('Not  Recognized','message');
        return  
end   
elseif (570000<X) && (X<580000)
      Seethrough10=imcrop(img1,[859, 12, 180, 70]);
x = pakcheck (Seethrough10);
Seethrough10=imcrop(img1,[700, 440, 190, 910]);
    y= pakbrs(Seethrough10);

if x==7 || y==1
    
    Identifier100=imcrop(BW,[179, 330 ,85, 100]); 
identifier = numel(Identifier100);
%disp('identifier');
%disp(identifier);

Seethrough100=imcrop(BW,[35, 39 ,210, 295-165]);
seethrough = numel(Seethrough100);
%disp('SEE THROUGH');
%disp(seethrough);
Front100=imcrop(BW,[964,88,125, 290-190]);
front = numel(Front100);
%disp('FRONT');
%disp(front);
else 
        h=msgbox('not Recognized','message');
        return  
end   

elseif (580000<X) && (X<610000)
    
      Seethrough10=imcrop(img1,[920, 12, 200, 70]);
x = pakcheck (Seethrough10);
Seethrough10=imcrop(img1,[700, 430, 190, 960]);
    y= pakbrs(Seethrough10);
if x==7 || y==1
Identifier500=imcrop(BW,[195, 360 ,85, 70]);
identifier = numel(Identifier500);
%disp('identifier');
%disp(identifier);
Seethrough500=imcrop(BW,[40, 10,  220, 290-155]);
seethrough = numel(Seethrough500);
%disp('SEE THROUGH');
%disp(seethrough);
Front500=imcrop(BW,[986, 75, 145, 305-215]);
front = numel(Front500);
%disp('FRONT');
%disp(front);
else 
        h=msgbox('Not Recognized','message');
        return  
end   

elseif (620000<X) && (X<660000)
    Seethrough10=imcrop(img1,[972, 12, 200, 70]);
x = pakcheck (Seethrough10);
Seethrough10=imcrop(img1,[750, 450, 200, 960]);
    y= pakbrs(Seethrough10);
if x==7 || y==1
    
    Identifier1000=imcrop(BW,[195, 330 ,85, 110]);
    identifier = numel(Identifier1000);
%disp('identifier');
%disp(identifier);

Seethrough1000=imcrop(BW,[35, 20,  280, 310-165]);
seethrough = numel(Seethrough1000);
%disp('SEE THROUGH');
%disp(seethrough);


Front1000=imcrop(BW,[1015, 62, 180, 320-237]);
front = numel(Front1000);
%disp('FRONT');
%disp(front);
else 
        h=msgbox('Not Recognized','message');
        return  
end   
elseif (663000<X) && (X<695000)
     Seethrough10=imcrop(img1,[1042, 12, 200, 70]);
x = pakcheck (Seethrough10);
  Seethrough10=imcrop(img1,[846, 450, 200, 960]);
    y= pakbrs(Seethrough10);
if x==7 || y==1
     Identifier5000=imcrop(BW,[195, 315 ,85, 130]);
    identifier = numel(Identifier5000);
%disp('identifier');
%disp(identifier);

Seethrough5000=imcrop(BW,[40, 20,  290, 310-165]);
seethrough = numel(Seethrough5000);
%disp('SEE THROUGH');
%disp(seethrough);
Front5000=imcrop(BW,[1065, 90, 200, 315-219]);
front = numel(Front5000);
%disp('FRONT');
%disp(front);  
else 
    h=msgbox( 'Not Recognized','message');
    return
end
else 
    h=msgbox('Currency Not Recognized','message');
    return
end
set(handles.height,'String',height);
set(handles.edit8,'String',width);
set(handles.edit9,'String',euler);
set(handles.area,'String',area);
set(handles.edit11,'String',aspectRatio);
height=str2double(height);
width=str2double(width);
area=double(area);
aspectRatio=double(aspectRatio);
euler=double(euler);
identifier=double(identifier);
seethrough=double(seethrough);
front=double(front);
fd=load('Finaldb.mat');
mytable=table(height,width,area,aspectRatio,euler,identifier,seethrough,front);
%disp(mytable.height);
%disp(mytable.width);
%disp(mytable.area);
%disp(mytable.aspectRatio);
%disp(mytable.euler);
%disp(mytable.identifier);
%disp(mytable.seethrough);
%disp(mytable.front);
yfit=fd.LinearSvm.predictFcn(mytable);
%disp(yfit);
%yen=FIRST(height,width,area,aspectRatio,euler,identifier,seethrough,front);
%disp(yen);
set(handles.edit12,'String',yfit);
h=imshow(img1, 'Parent', handles.axes2);
lineColor = java.awt.Color(1,0,0);  % =red
thickness = 3;  % pixels
roundedCorners = true;
newBorder = javax.swing.border.LineBorder(lineColor,thickness,roundedCorners);
edit12.Border = newBorder;

function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double
% --- Executes during object creation, after setting all properties.
 
b=str2double(get(hObject,'String'));
setappdata(0,'b',b);
ws = str2num(char(editBoxContents));
ws1 = str2double(cell2mat(editBoxContents));
%disp(ws);
%disp(ws1);
amount=get(handles.edit12);
setappdata(0,'edit12',amount);



function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','cyan');
end



function areabox_Callback(hObject, eventdata, handles)
% hObject    handle to area (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of area as text
%        str2double(get(hObject,'String')) returns contents of area as a double



% --- Executes during object creation, after setting all properties.
function areabox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to area (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function height_Callback(hObject, eventdata, handles)
% hObject    handle to height (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of height as text
%        str2double(get(hObject,'String')) returns contents of height as a double


% --- Executes during object creation, after setting all properties.
function height_CreateFcn(hObject, eventdata, handles)
% hObject    handle to height (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function path_Callback(hObject, eventdata, handles)
% hObject    handle to path (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of path as text
%        str2double(get(hObject,'String')) returns contents of path as a double


% --- Executes during object creation, after setting all properties.
function path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to path (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function area_Callback(hObject, eventdata, handles)
% hObject    handle to area (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of area as text
%        str2double(get(hObject,'String')) returns contents of area as a double


% --- Executes during object creation, after setting all properties.
function area_CreateFcn(hObject, eventdata, handles)
% hObject    handle to area (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Convert.
function Convert_Callback(hObject, eventdata, handles)
% hObject    handle to Convert (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)
getappdata(0,'edit12');
axis on
  ClearImagesFromAxes(handles.axes1)
     axes(handles.axes1);axis on
        set(handles.axes1,'xtick',[],'ytick',[]);
        ClearImagesFromAxes(handles.axes2)
         axes(handles.axes2);axis on
        set(handles.axes2,'xtick',[],'ytick',[]);
conversion_currency
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version2 of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h=findobj('tag','edit12');
value=h.String;
value=str2double(value);
if value==10
[y,Fs] = audioread('10.MP3');
sound(y,Fs);
elseif value==20
        [y,Fs] = audioread('20.MP3');
        sound(y,Fs);
    elseif value==50
            [y,Fs] = audioread('50.MP3');
             sound(y,Fs);
        elseif value==100
                    [y,Fs] = audioread('100.MP3');
                      sound(y,Fs)
                    
                elseif value==500
                            [y,Fs] = audioread('500.MP3');
             sound(y,Fs)
                        elseif value==1000
                                    [y,Fs] = audioread('1000.MP3');
             sound(y,Fs)
elseif   value==5000
                                         [y,Fs] = audioread('5000.MP3');
             sound(y,Fs)
else
      [y,Fs] = audioread('NO_CUR.MP3');
             sound(y,Fs)
    
  
end
