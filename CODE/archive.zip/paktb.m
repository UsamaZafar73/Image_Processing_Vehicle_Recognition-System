
function  y = paktb (Seethrough10)
%imshow(Seethrough10);
y=0;
seethrough = numel(Seethrough10);
%disp('part got');
%disp(seethrough);
if seethrough==0
    y=0;
    return
end
%disp('SEE THROUGH');
%disp(seethrough);
txt = ocr(Seethrough10,'Language','D:\MAYINSTALL\bin\PAKISTAN\myLang\tessdata\myLang.traineddata');
%disp(txt.Words);
   if( txt.Text(1) == 'P' &&  txt.Text(2) == 'A' &&  txt.Text(3) == 'K' &&  txt.Text(4) == 'I' &&  txt.Text(5) == 'S' &&  txt.Text(6) == 'T' &&  txt.Text(7) == 'A' &&  txt.Text(8) == 'N')
        y=1;
   else
       y=2;
   end
   %disp (y);
%disp(txt.Words);
%disp ('return result');
%disp(y);
return 
end 