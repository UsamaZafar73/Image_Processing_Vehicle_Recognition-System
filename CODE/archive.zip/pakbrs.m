
function  y = pakbrs (Seethrough10)
%imshow(Seethrough10);
y=0;
seethrough = numel(Seethrough10);
%disp('part got');
%disp(seethrough);
if seethrough==0
    y=0;
    return
end
%disp('SEE THROUGH');
%disp(seethrough);
txt = ocr(Seethrough10,'Language','D:\MAYINSTALL\bin\BACK\myLang\tessdata\myLang.traineddata');
%disp(txt.Words);
   if( txt.Text(1) == 'R' &&  txt.Text(2) == 'U' &&  txt.Text(3) == 'P' &&  txt.Text(4) == 'E' &&  txt.Text(5) == 'E' &&  txt.Text(6) == 'S')
  y=1;
   end
%disp(txt.Words);
%disp(y);
return 
end 